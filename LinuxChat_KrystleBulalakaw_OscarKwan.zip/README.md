# linux-chat

Linux client/server chat application with multiplexed I/O

#### Team
- Krystle Bulalakaw
- Oscar Kwan
